# Qantara Backend — دليل النشر

## الخطوات (5 دقائق فقط)

### 1. GitHub
1. اذهب إلى github.com
2. اضغط "New repository"
3. اسمه: `qantara-backend`
4. اضغط "Create repository"
5. ارفع الملفات الثلاثة: `api/analyze.js` و `vercel.json` و `package.json`

### 2. Vercel
1. اذهب إلى vercel.com
2. اضغط "Add New Project"
3. اختر مستودع `qantara-backend` من GitHub
4. اضغط "Deploy"

### 3. إضافة API Key
1. في Vercel → اذهب إلى Settings → Environment Variables
2. اضغط "Add New"
3. Name: `ANTHROPIC_API_KEY`
4. Value: مفتاحك من console.anthropic.com
5. اضغط Save
6. اضغط "Redeploy"

### 4. رابط الـ API
بعد النشر ستحصل على رابط مثل:
`https://qantara-backend.vercel.app/api/analyze`

هذا الرابط يُضاف في ملف الأداة (qantara-tool.html)

## اختبار الـ API
```
POST https://qantara-backend.vercel.app/api/analyze
Content-Type: application/json

{
  "mode": "analyze",
  "url": "https://www.qantara.it",
  "companyName": "Qantara",
  "industry": "تقنية",
  "country": "النرويج"
}
```
