const https = require('https');
const http = require('http');

// Helper: fetch a URL and return text
function fetchUrl(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const req = client.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; QantaraBot/1.0)',
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'ar,en;q=0.9',
      },
      timeout: 8000
    }, (res) => {
      // Handle redirects
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchUrl(res.headers.location).then(resolve).catch(reject);
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

// Helper: strip HTML tags and clean text
function cleanHtml(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<nav[\s\S]*?<\/nav>/gi, '')
    .replace(/<footer[\s\S]*?<\/footer>/gi, '')
    .replace(/<header[\s\S]*?<\/header>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .trim()
    .substring(0, 3000); // limit to 3000 chars
}

// Helper: call Claude API
function callClaude(prompt, apiKey) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }]
    });

    const options = {
      hostname: 'api.anthropic.com',
      path: '/v1/messages',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'Content-Length': Buffer.byteLength(body)
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch(e) {
          reject(new Error('Invalid JSON from Claude'));
        }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

module.exports = async (req, res) => {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'API key not configured' });

  const {
    url, companyName, industry, description,
    country, audience, competitors, goals, mode,
    platforms, tone, count, analysisData, customTopic
  } = req.body || {};

  try {

    // ── MODE 1: ANALYZE ──────────────────────────────
    if (mode === 'analyze') {
      let websiteContent = '';

      // Try to fetch website
      if (url) {
        try {
          const rawHtml = await fetchUrl(url.startsWith('http') ? url : 'https://' + url);
          websiteContent = cleanHtml(rawHtml);
        } catch(e) {
          websiteContent = '';
        }
      }

      const websiteSection = websiteContent
        ? `\n\nمحتوى الموقع الإلكتروني:\n"""\n${websiteContent}\n"""`
        : '';

      const prompt = `أنت خبير تسويق رقمي محترف ومحلل أعمال متخصص في السوق العربي.

قم بتحليل شامل ودقيق للشركة التالية:
- الاسم: ${companyName || 'غير محدد'}
- المجال: ${industry || 'غير محدد'}
- الوصف: ${description || 'غير محدد'}
- الموقع الإلكتروني: ${url || 'غير متاح'}
- السوق المستهدف: ${country || 'الشرق الأوسط'}
- الجمهور: ${audience || 'غير محدد'}
- المنافسون: ${competitors || 'غير محددين'}
- الأهداف: ${(goals || []).join('، ')}
${websiteSection}

بناءً على كل هذه المعلومات${websiteContent ? ' ومحتوى الموقع الإلكتروني' : ''}، أعطني تحليلاً شاملاً ودقيقاً.

أعطني JSON فقط بدون أي نص إضافي:
{
  "scores": {
    "market_opportunity": 85,
    "content_potential": 90,
    "competition_level": 65
  },
  "summary": "ملخص تنفيذي دقيق 3-4 جمل",
  "website_insights": "${websiteContent ? 'ما اكتشفته من الموقع' : ''}",
  "products_services": {
    "main": ["خدمة1", "خدمة2", "خدمة3"],
    "unique_value": "ما يميز هذه الشركة تحديداً"
  },
  "target_audience": {
    "primary": "الجمهور الأساسي",
    "secondary": "الجمهور الثانوي",
    "pain_points": ["مشكلة1", "مشكلة2", "مشكلة3"],
    "desires": ["رغبة1", "رغبة2", "رغبة3"]
  },
  "market_analysis": {
    "opportunities": ["فرصة1", "فرصة2", "فرصة3"],
    "challenges": ["تحدي1", "تحدي2"],
    "competitor_weaknesses": ["نقطة ضعف1", "نقطة ضعف2"]
  },
  "content_strategy": {
    "best_topics": ["موضوع1", "موضوع2", "موضوع3", "موضوع4"],
    "content_pillars": ["ركيزة1", "ركيزة2", "ركيزة3"],
    "recommended_tone": "النبرة الموصى بها",
    "posting_frequency": "تكرار النشر الموصى به",
    "content_ideas": ["فكرة محتوى محددة1", "فكرة2", "فكرة3"]
  },
  "strengths": ["قوة1", "قوة2", "قوة3"],
  "recommendations": ["توصية عملية1", "توصية2", "توصية3"]
}`;

      const claudeRes = await callClaude(prompt, apiKey);
      const txt = (claudeRes.content || []).map(c => c.text || '').join('');
      const match = txt.match(/\{[\s\S]*\}/);

      if (!match) throw new Error('Could not parse analysis');
      const analysis = JSON.parse(match[0]);
      analysis.website_fetched = !!websiteContent;

      return res.status(200).json({ success: true, analysis });
    }

    // ── MODE 2: GENERATE POSTS ────────────────────────
    if (mode === 'generate') {
      const ctx = analysisData ? `
بناءً على التحليل الذكي للشركة:
- نقاط ألم الجمهور: ${(analysisData.target_audience?.pain_points || []).join('، ')}
- أفضل مواضيع المحتوى: ${(analysisData.content_strategy?.best_topics || []).join('، ')}
- أفكار محتوى مقترحة: ${(analysisData.content_strategy?.content_ideas || []).join('، ')}
- ركائز المحتوى: ${(analysisData.content_strategy?.content_pillars || []).join('، ')}
- القيمة المميزة للشركة: ${analysisData.products_services?.unique_value || ''}
- رغبات الجمهور: ${(analysisData.target_audience?.desires || []).join('، ')}
` : '';

      const prompt = `أنت خبير تسويق رقمي محترف متخصص في السوق العربي وإنشاء محتوى سوشيال ميديا.

بيانات الشركة:
- الاسم: ${companyName || 'شركتك'}
- المجال: ${industry || 'أعمال'}
- الوصف: ${description || 'لم يُحدد'}
- السوق: ${country || 'الشرق الأوسط'}
- الجمهور: ${audience || 'الجمهور العام'}
${ctx}
${customTopic ? `التركيز الخاص: ${customTopic}` : ''}

المطلوب: أنشئ بالضبط ${count || 5} منشورات لمنصات: ${(platforms || ['instagram']).join(' و ')}.
النبرة: ${tone || 'احترافي'}.

أعطني JSON array فقط بدون أي نص إضافي:
[
  {
    "platform": "اسم المنصة",
    "text": "نص المنشور الكامل باللغة العربية مع إيموجي مناسبة ومؤثرة",
    "hashtags": ["هاشتاق1","هاشتاق2","هاشتاق3","هاشتاق4","هاشتاق5"],
    "image_prompt": "وصف الصورة المثالية لهذا المنشور بالإنجليزية لتوليدها بالذكاء الاصطناعي"
  }
]

قواعد صارمة:
- كل منشور مختلف تماماً في الأسلوب والموضوع والزاوية
- استخدم العربية المناسبة للدولة المستهدفة
- الهاشتاقات بدون رمز # في JSON
- image_prompt يكون وصفاً احترافياً بالإنجليزية للصورة`;

      const claudeRes = await callClaude(prompt, apiKey);
      const txt = (claudeRes.content || []).map(c => c.text || '').join('');
      const match = txt.match(/\[[\s\S]*\]/);

      if (!match) throw new Error('Could not parse posts');
      const posts = JSON.parse(match[0]);

      return res.status(200).json({ success: true, posts });
    }

    return res.status(400).json({ error: 'Invalid mode' });

  } catch(e) {
    console.error('Error:', e.message);
    return res.status(500).json({ error: e.message });
  }
};
